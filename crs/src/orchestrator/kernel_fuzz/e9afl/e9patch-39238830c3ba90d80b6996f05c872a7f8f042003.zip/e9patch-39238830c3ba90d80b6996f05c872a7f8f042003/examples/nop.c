/*
 * NOP instrumentation (does nothing).
 */

void entry(void)
{
    return;
}

