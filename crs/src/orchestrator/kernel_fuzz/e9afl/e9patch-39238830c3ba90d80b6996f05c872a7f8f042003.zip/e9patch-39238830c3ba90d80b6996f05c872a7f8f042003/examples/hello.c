/*
 * "Hello World" instrumentation.
 */

#include "stdlib.c"

/*
 * Print "Hello World!"
 */
void entry(void)
{
    puts("Hello World!");
}

