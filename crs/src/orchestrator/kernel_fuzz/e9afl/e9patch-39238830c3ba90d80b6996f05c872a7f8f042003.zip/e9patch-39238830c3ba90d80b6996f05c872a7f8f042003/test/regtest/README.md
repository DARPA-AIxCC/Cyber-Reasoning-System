README
======

To run the tests:

    $ make
    $ ./regtest

